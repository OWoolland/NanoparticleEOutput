#include "SurfaceEnergy.hh"
#include "PlottingTool.hh"
#include "SurfaceEnergy.hh"
#include "StackingTool.hh"
#include "MemMapRead.hh"
#include "WorkerManager.hh"
#include "WritingTool.hh"

#include <iostream>  // printing
#include <fstream>   // reading file
#include <unistd.h>  // delay (usleep)

using namespace std;

/**************************************************
Flow of class:
  - Process the command line parameters
  - Create the stacking tool
  - Create the analysis tool
  - Create the worker threads
  - Create the file reader
  - At EOF ensure the stack is empty
  - Destroy all objects
  - Call the plotting tool
**************************************************/

int main(int argc, char* argv[])
{
  // Process command line parameters

  if (argc < 2) {
    cerr << "Usage: (NOT IMPLIMENTED)" << argv[0] << " <options> DATAFILE OUTFILE\n"
	 << "Options:\n"
	 << "\t-h,--help\t\tShow this help message\n"
	 << endl;
    return 0;
  }
 
  const char * fileName = argv[1];
  const char * outFileName = argv[2];
  
  // Create stacking and analysis tools and the worker threads
  StackingTool* stackTool = new StackingTool;
  SurfaceEnergy* surfAnalyser = new SurfaceEnergy();
  WritingTool* writeTool = new WritingTool(outFileName);

  WorkerManager* workerMan = new WorkerManager(surfAnalyser, stackTool, writeTool);
  workerMan->beginThreads(2);
  
  // Create file reader thread, await EOF and empty stack
  MemMapRead* memMapReader = new MemMapRead(fileName, surfAnalyser, stackTool);
  memMapReader->beginReader();
  usleep(1000);
  while(!memMapReader->getFinished()&&stackTool->getStackSize()!=0) {
    memMapReader->printCurrentProgress();
    usleep(60000000);
  }

  // Call plotting tool
  PlottingTool* plotter = new PlottingTool();
  //  plotter->setTitle("10^7 Photons");
  plotter->setXLabel("Energy (eV)");
  plotter->setYLabel("Count");

  //plotter->setFile("../../../surface_only_dataset.csv");
  plotter->setFile(outFileName);
  //plotter->setFile(surfAnalyser->GetOutFileName());
  
  //plotter->setPlotParameters("");
  
  //plotter->plotXY(0,  // xCol
  //		  6); // yCol

  plotter->setPlotParameters("smooth freq with boxes notitle");

  plotter->plotHist(1254, // nBins
  		    1254,     // minValue
  		    0, // maxValue
  		    1);    // file column
}

