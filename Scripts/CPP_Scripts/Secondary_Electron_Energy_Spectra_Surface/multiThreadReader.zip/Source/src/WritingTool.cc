#include "WritingTool.hh"

#include <iostream>  // printing
#include <pthread.h> // multithreading
#include <fstream>   // reading file

using namespace std;

/**************************************************
Flow of class:
  - Accept lines from other classes to write to output file
**************************************************/

static ofstream ofile;
pthread_mutex_t ofile_mutex = PTHREAD_MUTEX_INITIALIZER;

WritingTool::WritingTool(const char * outFileName) {
  ofile.open(outFileName);
}

WritingTool::~WritingTool() {
}

void WritingTool::writeLine(string line) {
  pthread_mutex_lock(&ofile_mutex);
    ofile << line << endl;
  pthread_mutex_unlock(&ofile_mutex);
}

