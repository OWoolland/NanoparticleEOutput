#ifndef WritingTool_h
#define WritingTool_h 1

#include <sstream>   // stringstream

using namespace std;

class WritingTool {
  public:
    WritingTool(const char* outFileName);
    virtual ~WritingTool();

    virtual void writeLine(string line);  
      
  private:
};

#endif
