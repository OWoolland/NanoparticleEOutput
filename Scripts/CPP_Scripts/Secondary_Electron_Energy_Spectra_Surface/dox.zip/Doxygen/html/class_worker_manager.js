var class_worker_manager =
[
    [ "WorkerManager", "class_worker_manager.html#af684cc4b5447e99d3590aec2275c20ca", null ],
    [ "~WorkerManager", "class_worker_manager.html#a2245163719090a6feb4964abb20737de", null ]
];