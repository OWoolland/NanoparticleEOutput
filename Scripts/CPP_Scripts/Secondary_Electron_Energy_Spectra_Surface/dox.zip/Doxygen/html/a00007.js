var a00007 =
[
    [ "WritingTool", "a00007.html#aa99eec577a3c8df1f118c03adf61c181", null ],
    [ "~WritingTool", "a00007.html#af1904d6ba6ab50d2ab78d05e35e92957", null ],
    [ "writeLine", "a00007.html#acf7eb7c0a554eeca07f9fa36c7624da5", null ]
];