var a00002 =
[
    [ "MemMapRead", "a00002.html#a0662c28f4e0f5be658854c9295cfcd99", null ],
    [ "~MemMapRead", "a00002.html#abe499d3df91e60aaac7c5aff7b1eb828", null ],
    [ "beginReader", "a00002.html#a59dfbd656e4d1ce804536275283b355b", null ],
    [ "getFinished", "a00002.html#a77c0c02e3a128f9ff062650850595ba0", null ],
    [ "mapFile", "a00002.html#a4bec850d40be73af739731bf01ff60b4", null ],
    [ "printCurrentProgress", "a00002.html#a62fb4b244efbfe631b0d170896d3c4af", null ],
    [ "readFile", "a00002.html#ae2b556a88be20b14ebf49a12b341e9e8", null ]
];