var class_writing_tool =
[
    [ "WritingTool", "class_writing_tool.html#aa99eec577a3c8df1f118c03adf61c181", null ],
    [ "~WritingTool", "class_writing_tool.html#af1904d6ba6ab50d2ab78d05e35e92957", null ],
    [ "writeLine", "class_writing_tool.html#acf7eb7c0a554eeca07f9fa36c7624da5", null ]
];