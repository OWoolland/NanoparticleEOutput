var a00021 =
[
    [ "analyser", "a00021.html#acfac35869b27215ffb2c975a3378b981", null ],
    [ "nThreads", "a00021.html#a8adda9db6d1fb7be6f86999c24c75ab0", null ],
    [ "stackingTool", "a00021.html#a39cea9078b4adacf322b4ac1eb1b15c8", null ],
    [ "writingTool", "a00021.html#aa83f79897a28a74bd8de64ff3c53dcf8", null ]
];