var searchData=
[
  ['writingtool',['writingTool',['../_worker_manager_8cc.html#aa83f79897a28a74bd8de64ff3c53dcf8',1,'WorkerManager.cc']]]
];
