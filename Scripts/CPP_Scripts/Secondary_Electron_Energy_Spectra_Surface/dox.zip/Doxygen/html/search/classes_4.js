var searchData=
[
  ['workermanager',['WorkerManager',['../class_worker_manager.html',1,'']]],
  ['writingtool',['WritingTool',['../class_writing_tool.html',1,'']]]
];
