var a00006 =
[
    [ "WorkerManager", "a00006.html#af684cc4b5447e99d3590aec2275c20ca", null ],
    [ "~WorkerManager", "a00006.html#a2245163719090a6feb4964abb20737de", null ],
    [ "beginThreads", "a00006.html#a241622d11457d8e9d26b3aa1d853b2b0", null ],
    [ "threadAction", "a00006.html#a6bc86f30cf419c22934d5a6e205775b1", null ]
];