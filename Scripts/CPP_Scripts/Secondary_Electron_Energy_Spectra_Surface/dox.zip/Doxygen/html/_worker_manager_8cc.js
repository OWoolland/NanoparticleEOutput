var _worker_manager_8cc =
[
    [ "analyser", "_worker_manager_8cc.html#acfac35869b27215ffb2c975a3378b981", null ],
    [ "nThreads", "_worker_manager_8cc.html#a8adda9db6d1fb7be6f86999c24c75ab0", null ],
    [ "stackingTool", "_worker_manager_8cc.html#a39cea9078b4adacf322b4ac1eb1b15c8", null ],
    [ "writingTool", "_worker_manager_8cc.html#aa83f79897a28a74bd8de64ff3c53dcf8", null ]
];