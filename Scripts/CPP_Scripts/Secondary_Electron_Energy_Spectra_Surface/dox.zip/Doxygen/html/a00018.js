var a00018 =
[
    [ "gnuplot_script", "a00018.html#acc022f2d91b35671506e9355c8506905", null ],
    [ "scriptFile", "a00018.html#aebfa6e8e5ebe5bb29643910923512797", null ],
    [ "scriptParams", "a00018.html#a39d83b97d2c6734ef089ad4d522b5191", null ],
    [ "scriptTitle", "a00018.html#a8c278975161ac0ee6b975d2e82677144", null ],
    [ "scriptXLabel", "a00018.html#a49feeec1e732cbf372c782d1e9ff6844", null ],
    [ "scriptYLabel", "a00018.html#a15d203cc37d6b9ed8c364f19e0501ff5", null ]
];