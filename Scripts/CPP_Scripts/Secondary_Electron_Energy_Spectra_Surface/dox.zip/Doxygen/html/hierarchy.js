var hierarchy =
[
    [ "AnalysisTool", "class_analysis_tool.html", [
      [ "SurfaceEnergy", "class_surface_energy.html", null ],
      [ "WorkerManager", "class_worker_manager.html", null ]
    ] ],
    [ "MemMapRead", "class_mem_map_read.html", null ],
    [ "PlottingTool", "class_plotting_tool.html", null ],
    [ "StackingTool", "class_stacking_tool.html", null ],
    [ "WritingTool", "class_writing_tool.html", null ]
];