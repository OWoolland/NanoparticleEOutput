var class_stacking_tool =
[
    [ "StackingTool", "class_stacking_tool.html#ab83491d062add93b6340b89003ce760a", null ],
    [ "~StackingTool", "class_stacking_tool.html#a38e6fb24f3a84e54afcb036bdf542fce", null ],
    [ "getStackSize", "class_stacking_tool.html#a19d4dcb02fea29c76ac4488c8eea21f5", null ],
    [ "giveLine", "class_stacking_tool.html#aa6ff12c0d2f0a436fd5abd35a0c8a8f6", null ],
    [ "stackLine", "class_stacking_tool.html#a7935feba7f8be38824e3514b6b09c111", null ]
];